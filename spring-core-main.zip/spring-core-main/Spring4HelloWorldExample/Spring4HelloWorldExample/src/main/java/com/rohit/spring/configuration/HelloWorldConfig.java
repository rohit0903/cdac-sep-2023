package com.rohit.spring.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Description;

import com.rohit.spring.domain.HelloWorld;
import com.rohit.spring.domain.HelloWorldImpl;

@Configuration
public class HelloWorldConfig {

	@Bean(name="helloWorldBean")
	public HelloWorld helloWorld() {
		return new HelloWorldImpl();
	}
	
}
